<html>
<head>
	<title>Студенти от ПМФ</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf8">
</head>
<body>
	<?php
		$txt1 = "Learn PHP";
		$x = 5;
		$y = 4;
		echo "<h2>" . $txt1 . "</h2>";
		echo $x + $y;
	?>
	
	<table border="1" align="center">
	  <tr>
		<td>ID</td>
		<td>ФН</td>
		<td>Име</td>
		<td>Презиме</td>
		<td>Фамилия</td>
		<td>Курс</td>
		<td>Лаб.група</td>
		<td>Избираема дисциплина</td>
	  </tr>
	</table>
	<?php
		echo 'Hello!';
	?>
</body>
</html>
