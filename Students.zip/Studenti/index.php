<?php
header("Location: students.php"); /* Redirect browser */
exit;
?>