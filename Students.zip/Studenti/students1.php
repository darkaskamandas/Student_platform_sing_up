<?php
include_once "config.php";
?>

<html>
<head>
	<title>Студенти от ПМФ</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf8">
</head>
<body>
	<h3 align="center">Студенти от ПМФ</h3>
	<table border="1" align="center">
	  <tr>
		<td>ID</td>
		<td>ФН</td>
		<td>Име</td>
		<td>Презиме</td>
		<td>Фамилия</td>
		<td>Курс</td>
		<td>Лаб.група</td>
		<td>Избираема дисциплина</td>
	  </tr>	
		<?php
		$result=mysqli_query($connection,"SELECT * FROM students");
		if (mysqli_num_rows($result)>0)
		{  
			while($row_students=mysqli_fetch_array($result))
			{
			  echo 
				'<tr>
					   <td>'.$row_students['id'] .'</td>
					   <td>'.$row_students['fnum'].'</td>
					   <td>'.$row_students['fname'].'</td>
					   <td>'.$row_students['mname'].'</td>
					   <td>'.$row_students['lname'].'</td>
					   <td>'.$row_students['course'].'</td>
					   <td>'.$row_students['lgroup'].'</td>
					   <td>'.$row_students['course_id'].'</td>
				</tr>';
			}
		}
			else {echo "Няма записани студенти";}
		?>
  </table>
</body>
</html>
