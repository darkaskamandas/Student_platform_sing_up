<?php
include_once "config.php";
?>

<html>
<head>
	<title>Студенти от ПМФ</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf8">
</head>
<body>
	<h3 align="center">Студенти от ПМФ</h3>
	<?php include_once "links.htm"; ?>
	<table border="1" align="center">	
	<tr>
		<td colspan="5">
			<form name="form_course" action="students3.php" method="get">
				<select name="courses">
				   <option value="0">Всички дисциплини</option>
				   <?php
					$result_courses=mysqli_query($connection,"select * from courses");
				    while($row_course=mysqli_fetch_array($result_courses))
				    {
						echo '<option value='.$row_course['id'].'>'.$row_course['name'].'</option>';
				    }
				  ?>
				</select>
				<input type="submit" value="сортирай">
			</form>
		</td>
		<td colspan="3">
		<?php
		if (isset($_GET['courses']) && $_GET['courses']!=0)
		{
		$result=@mysqli_query($connection,"SELECT * FROM teachers where course_id=$_GET[courses];");
		$row_teacher=@mysqli_fetch_array($result);
		echo 'Преподавател: '.$row_teacher['fname'].'&nbsp'.$row_teacher['lname'];
		}
		?>

		</td>
	</tr>
	<tr>
		<td>ID</td>
		<td>ФН</td>
		<td>Име</td>
		<td>Презиме</td>
		<td>Фамилия</td>
		<td>Курс</td>
		<td>Лаб.група</td>
		<td>Избираема дисциплина</td>
	</tr>	  

		<?php
		if (isset($_GET['courses']) && $_GET['courses']!=0)
		{$result=@mysqli_query($connection,"select * from students, courses WHERE students.course_id=$_GET[courses] AND courses.id=$_GET[courses];");}
		else 
		{$result=mysqli_query($connection,"select * from students, courses WHERE students.course_id=courses.id;");}
			if (mysqli_num_rows($result)>0)
			{  
				while($row_students=mysqli_fetch_array($result))
				{
				  echo 
					'<tr>
						   <td>'.$row_students['id'] .'</td>
						   <td>'.$row_students['fnum'].'</td>
						   <td>'.$row_students['fname'].'</td>
						   <td>'.$row_students['mname'].'</td>
						   <td>'.$row_students['lname'].'</td>
						   <td>'.$row_students['course'].'</td>
						   <td>'.$row_students['lgroup'].'</td>
						   <td>'.$row_students['name'].'</td>
					</tr>';
				}
			}
			else {echo "Няма записани студенти";}
		?>
  </table>
</body>
</html>
