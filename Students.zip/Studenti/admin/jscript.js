function validate_form() 
			{ 
				valid = true;
				
				if (isNaN(document.addstudent.fnum.value)) 
				{ 
					valid = false;
					alert ("Полето 'Факултетен номер' трябва да съдържа само цифри"); 
					document.addstudent.fnum.focus();
				} 
				else if (document.addstudent.fname.value == "") 
				{ 
					alert ("Мoля попълнете полето 'Име', то е задължително!"); 
					document.addstudent.fname.focus();
					valid = false; 
				} 
				else if (document.addstudent.lname.value == "") 
				{ 
					alert ("Моля попълнете полето 'Фамилия', то е задължително!"); 
					document.addstudent.lname.focus();
					valid = false; 
				} 				
				else if (document.addstudent.lgroup.selectedIndex == 0) 
				{ 
					alert ("Моля изберете лабораторна група"); 
					document.addstudent.lgroup.focus ();
					valid = false; 
				} 								
				else
				{ 
					document.addstudent.submit();					
				} 

				return valid; 
				
			} 