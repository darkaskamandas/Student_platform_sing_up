﻿<?php
//session_start();
if (!isset($_SESSION)) { 
  // no session has been started yet
  session_start(); 
}
if(!isset($_SESSION['user'])){header("Location:index.php");}
include_once "config.php";
?>
<html>
<head>
	<title>Дисциплини от ПМФ</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf8">
	<link href="style.css" rel="stylesheet" type="text/css">
	<?php
	if(isset($_GET['dell']))
	{
		echo '<script type="text/javascript">
		<!--		
		var answer = confirm ("Дисциплинa No '.$_GET['dell'].' ЩЕ БЪДE ИЗТРИТ ОТ БАЗА ДАННИ")
		if (answer)
		{window.location="courses.php?delltrue='.$_GET['dell'].'";}
		else
		{window.location="courses.php";}
		// -->
		</script>';
	}

	if(isset($_GET['delltrue']))
	{
		mysqli_query($connection,"DELETE FROM courses WHERE id='$_GET[delltrue]'"); 
		mysqli_query($connection,"OPTIMIZE TABLE courses");
	}
	?>
</head>
<body>
<?php
if(isset($_SESSION['user'])){echo '<p class="black12" align="center">Потребител: '.$_SESSION['user'].' - ';}
?>
<a href="index.php?logout"><strong>Изход</strong></a></p>
<?php include_once "links.htm";?>
<h3 align="center">Дисциплини от ПМФ</h3>
<p align="center">
	<a href="add_course.php"><strong>Добавяне на нова дисциплина</strong></a>
</p>
<table border="1" align="center">
<tr>
    <td colspan="4">
		<form name="form_course" action="courses.php" method="get">
		Избираема дисциплина:
		<select name="courses">
		   <option value="0" selected>Всички</option>
		   <?php
				$result_courses=mysqli_query($connection,"SELECT * FROM courses");
				while($row_course=mysqli_fetch_array($result_courses))
				    {
						echo '<option value='.$row_course['id'];
						if (isset($_GET['courses']) && $_GET['courses']==$row_course['id'])
						{echo ' selected>'.$row_course['name'].'</option>';}
						else {echo '>'.$row_course['name'].'</option>';}
				    }
			?>
		</select>
		<input type="submit" value="сортирай">
		</form>
	</td>
	 
  </tr>
  
  <tr>
    <td colspan="4">
		<form name="form_search" action="<?php $PHP_SELF; ?>" method="get">
		Въведете име:
		<input name="search_text" type="text">
		<input type="submit" value="търсене">
		</form>
	</td>	
  </tr>

  <tr>
    <td>ID</td>
    <td>Име</td>
	<td>Изтриване</td>
	<td>Редактиране</td>
  </tr>

  <?php
if (isset($_GET['courses']) && $_GET['courses']!=0)
	{$result=mysqli_query($connection,"SELECT * FROM courses WHERE courses.id=$_GET[courses];");}
elseif (isset($_GET['search_text']))
	 
	{$result=mysqli_query($connection,"SELECT * FROM courses WHERE (name LIKE '%$_GET[search_text]%')");
		if (mysqli_num_rows($result)==0)
		{
		echo '<tr><td colspan="10" align="center" bgcolor="FF0000">Няма намерени резултати</td></tr>';
		$result=mysqli_query($connection,"SELECT * FROM courses;");
		}
	}	
else 
	{$result=mysqli_query($connection,"SELECT * FROM courses;");}


while($row_students=mysqli_fetch_array($result, MYSQLI_BOTH))
  {
    echo 
	'<tr>
    	   <td>'.$row_students['0'].'</td>
    	   <td>'.$row_students['name'].'</td>
		   <td><a href="courses.php?dell='.$row_students['0'].'">Изтриване</a></td>
		   <td><a href="edit_course.php?id='.$row_students['0'].'">Редактиране</a></td>
  	</tr>';
  }
  ?>
</table>
</body>
</html>
