<?php
include_once "config.php";
?>
<html>
<head>
	<title>Студенти от ПМФ</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf8">
</head>
<body>
	<h3 align="center">Студенти от ПМФ</h3>
	<?php include_once "links.htm"; ?>
	<table border="1" align="center">
	  <tr>
		<td colspan="5">
			<form name="form_course" action="students2.php" method="get">
				<select name="courses">
					<option value="0">Всички дисциплини</option>
					<?php
					$result=mysqli_query($connection,"select * courses");
					if (mysqli_num_rows($result)>0)
					{  
						while($row_course=mysqli_fetch_array($result))
						{
						  echo '<option value='.$row_course['id'] .'>'.$row_course['name'].'</option>';
						}
					}
					?>	
				</select>
	<input type="submit" value="сортирай">
			</form>
		</td>
		<td colspan="3"></td>
	  </tr>	
	  <tr>
		<td>ID</td>
		<td>ФН</td>
		<td>Име</td>
		<td>Презиме</td>
		<td>Фамилия</td>
		<td>Курс</td>
		<td>Лаб.група</td>
		<td>Избираема дисциплина</td>
	  </tr>	
		<?php
		$result=mysqli_query($connection,"select * from students, courses where students.course_id=courses.id;");
		if (mysqli_num_rows($result)>0)
		{  
			while($row_students=mysqli_fetch_array($result))
			{
			  echo 
				'<tr>
					   <td>'.$row_students['id'] .'</td>
					   <td>'.$row_students['fnum'].'</td>
					   <td>'.$row_students['fname'].'</td>
					   <td>'.$row_students['mname'].'</td>
					   <td>'.$row_students['lname'].'</td>
					   <td>'.$row_students['course'].'</td>
					   <td>'.$row_students['lgroup'].'</td>
					   <td>'.$row_students['name'].'</td>
				</tr>';
			}
		}
		else {echo "Няма записани студенти";}
		?>
  </table>
</body>
</html>
